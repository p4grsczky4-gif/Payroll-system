# Bedriftsdemo – GitHub Pages

Samlet repository for tre lokale øvingsapper:

- **HR og lønn** – v1.16.0
- **Vaktplan og timeliste** – v2.1.0
- **Økonomi og nettbank** – v1.0.2

Åpne `index.html` via GitHub Pages. Appene lagrer data lokalt i nettleseren og sender ikke reelle lønns-, bank-, faktura- eller myndighetsdata.

Se `GITHUB-OPPLASTING.txt` for opplasting og iPhone-bruk.
